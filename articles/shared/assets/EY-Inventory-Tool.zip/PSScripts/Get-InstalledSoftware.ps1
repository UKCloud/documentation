 ##########################################################################
 # 
 # Get-InstalledSoftware
 #
 ##########################################################################

<#
.SYNOPSIS
 Retrieves list of installated applications from Remote Registry if WMI is disabled or not available

.PARAMETER      ComputerName
Accepts a single Computer Name
USAGE: .\Get-InstalledSoftware.ps1 -ComputerName comp-name

.PARAMETER      OutputFile
Output CSV file to store the results

#>

param(
	[alias("target")]	
    $ComputerName = $env:COMPUTERNAME,
    [alias("o1")]
    $OutputFile1 = $ComputerName + "_EY_PSEY_Applications.csv",
    [alias("o2")]
    $OutputFile2 = $ComputerName + "_EY_PSEY_System.csv",
	[alias("log")]
	[string] $LogFile = $ComputerName + "_EY_PSEY_ApplicationsLog.txt",
	[switch] $Verbose
)

function LogText {
	param(
		[Parameter(Position=0, ValueFromRemainingArguments=$true, ValueFromPipeline=$true)]
		[Object] $Object,
		[System.ConsoleColor]$color = [System.Console]::ForegroundColor,
		[switch]$NoNewLine = $false  
	)

	# Display text on screen
	Write-Host -Object $Object -ForegroundColor $color -NoNewline:$NoNewLine

	if ($LogFile) {
		$Object | Out-File $LogFile -Encoding utf8 -Append 
	}
}

function InitialiseLogFile {
	if ($LogFile -and (Test-Path $LogFile)) {
		Remove-Item $LogFile
	}
}

function LogProgress($progressDescription){
	if ($Verbose){
		LogText ""
	}

	$output = Get-Date -Format HH:mm:ss.ff
	$output += " - "
	$output += $progressDescription
	LogText $output -Color Green
}

function LogError([string[]]$errorDescription){
	if ($Verbose){
		LogText ""
	}

	$output = Get-Date -Format HH:mm:ss.ff
	$output += " - "
	$output += $errorDescription -join "`r`n              "
	LogText $output -Color Red
	Start-Sleep -s 3
}

function LogLastException() {
    $currentException = $Error[0].Exception;

    while ($currentException)
    {
        LogText -Color Red $currentException
        LogText -Color Red $currentException.Data
        LogText -Color Red $currentException.HelpLink
        LogText -Color Red $currentException.HResult
        LogText -Color Red $currentException.Message
        LogText -Color Red $currentException.Source
        LogText -Color Red $currentException.StackTrace
        LogText -Color Red $currentException.TargetSite

        $currentException = $currentException.InnerException
    }

	Start-Sleep -s 3
}

function LogEnvironmentDetails {
	LogText -Color Gray " "
	LogText -Color Gray "  ###########################################################"
	LogText -Color Gray "  #       _______     __                                    #"
	LogText -Color Gray "  #      |  ___\ \   / /                                    #"
	LogText -Color Gray "  #      | |__  \ \_/ /                                     #"
	LogText -Color Gray "  #      |  __|  \   /                  Ernst & Young       #"
	LogText -Color Gray "  #      | |____  | |        Windows Inventory Script       #"
	LogText -Color Gray "  #      |______| |_|                                       #"
	LogText -Color Gray "  #                                                         #"
	LogText -Color Gray "  ###########################################################"
	LogText -Color Gray " "
	LogText -Color Gray " Get-InstalledSoftware.ps1"
	LogText -Color Gray " "

	$OSDetails = Get-WmiObject Win32_OperatingSystem
	LogText -Color Gray "Computer Name:        $($env:COMPUTERNAME)"
	LogText -Color Gray "User Name:            $($env:USERNAME)@$($env:USERDNSDOMAIN)"
	LogText -Color Gray "Windows Version:      $($OSDetails.Caption)($($OSDetails.Version))"
	LogText -Color Gray "PowerShell Host:      $($host.Version.Major)"
	LogText -Color Gray "PowerShell Version:   $($PSVersionTable.PSVersion)"
	LogText -Color Gray "PowerShell Word size: $($([IntPtr]::size) * 8) bit"
	LogText -Color Gray "CLR Version:          $($PSVersionTable.CLRVersion)"
	LogText -Color Gray "Current Date Time:    $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
	LogText -Color Gray "Target:               $ComputerName"
	LogText -Color Gray "Output File 1:        $OutputFile1"
	LogText -Color Gray "Log File:             $LogFile"
	LogText -Color Gray ""
}

function SetupDateFormats {
    # Standardise date/time output to ISO 8601'ish format
    $bDateFormatConfigured = $false
    $currentThread = [System.Threading.Thread]::CurrentThread
    
    try {
        $CurrentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = 'yyyy-MM-dd'
        $CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern = 'yyyy-MM-dd HH:mm:ss'
        $bDateFormatConfigured = $true
    }
    catch {
    }

    if (!($bDateFormatConfigured)) {
        try {
            $cultureCopy = $CurrentThread.CurrentCulture.Clone()
            $cultureCopy.DateTimeFormat.ShortDatePattern = 'yyyy-MM-dd'
            $cultureCopy.DateTimeFormat.LongDatePattern = 'yyyy-MM-dd HH:mm:ss'
            $currentThread.CurrentCulture = $cultureCopy
        }
        catch {
        }
    }
}

function Get-InstalledSoftwareList {
    SetupDateFormats
	InitialiseLogFile
	LogEnvironmentDetails

	## Array for storing csv file details
	$results = @()

	$UninstallRegKeys = @("SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", 
							"SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall" )

	if(!(Test-Connection -ComputerName $ComputerName -Count 1 -ea 0)) {
		LogError "$ComputerName not reachable. Script Exiting"
		exit
	}
	
	$domainName = $env:USERDNSDOMAIN

	foreach($UninstallRegKey in $UninstallRegKeys) {
		try {
			LogProgress "Connecting to $ComputerName Remote Registry service ($UninstallRegKey)"

			$HKLM = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',$ComputerName)
			$UninstallRef = $HKLM.OpenSubKey($UninstallRegKey)
			$Applications = $UninstallRef.GetSubKeyNames()
				
		} catch {
			LogText "Unable to open root key $UninstallRegKey"
			Continue
		}

		foreach ($App in $Applications) {
			$AppRegistryKey  = $UninstallRegKey + "\\" + $App
			$AppDetails   = $HKLM.OpenSubKey($AppRegistryKey)
					
			$AppDisplayName  = $($AppDetails.GetValue("DisplayName"))
			$AppVersion   = $($AppDetails.GetValue("DisplayVersion"))
			$AppPublisher  = $($AppDetails.GetValue("Publisher"))
			$AppInstalledDate = $($AppDetails.GetValue("InstallDate"))
			$AppVersionMajor = $($AppDetails.GetValue("VersionMajor"))
			$AppVersionMinor  = $($AppDetails.GetValue("VersionMinor"))
							
			if(!$AppDisplayName) { 
				$AppDisplayName  = $($AppDetails.GetValue("QuietDisplayName")) 
			}
				
			if(!$AppDisplayName) { continue }

			$OutputObj = New-Object -TypeName PSobject 
			$OutputObj | Add-Member -MemberType NoteProperty -Name ComputerName -Value $ComputerName
			$OutputObj | Add-Member -MemberType NoteProperty -Name ComputerDomain -Value $domainName
			$OutputObj | Add-Member -MemberType NoteProperty -Name DisplayName -Value $AppDisplayName
			$OutputObj | Add-Member -MemberType NoteProperty -Name InstalledDate -Value $AppInstalledDate
			$OutputObj | Add-Member -MemberType NoteProperty -Name VersionMajor -Value $AppVersionMajor
			$OutputObj | Add-Member -MemberType NoteProperty -Name DisplayVersion -Value $AppVersion
			$OutputObj | Add-Member -MemberType NoteProperty -Name Publisher -Value $AppPublisher

			$results += $OutputObj
				
		}

		# Loop through Users
		$HKU = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('USERS',$ComputerName)				
		foreach($HKUser in $HKU.GetSubKeyNames()) {

			if ($HKUser -like "*_classes") {
				# No application data in this key. Move on.
				continue
			}

			try {
				try {
					$UserUninstallKey = $HKUser + "\" + $UninstallRegKey
					$UninstallRef  = $HKU.OpenSubKey($UserUninstallKey)
				}
				catch {
					LogText "Unable to open user key $UserUninstallKey. Insufficient privileges?"
					continue
				}

				if (!$UninstallRef) {
					continue
				}

				$Applications = $UninstallRef.GetSubKeyNames()
										
				foreach ($App in $Applications) {
					$AppRegistryKey  = $HKUser + "\\" + $UninstallRegKey + "\\" + $App
					$AppDetails   = $HKU.OpenSubKey($AppRegistryKey)
				
					$AppDisplayName  = $($AppDetails.GetValue("DisplayName"))
					$AppVersion   = $($AppDetails.GetValue("DisplayVersion"))
					$AppPublisher  = $($AppDetails.GetValue("Publisher"))
					$AppInstalledDate = $($AppDetails.GetValue("InstallDate"))
					$AppVersionMajor = $($AppDetails.GetValue("VersionMajor"))
					$AppVersionMinor  = $($AppDetails.GetValue("VersionMinor"))
							
					if(! $AppDisplayName) { 
						$AppDisplayName  = $($AppDetails.GetValue("QuietDisplayName")) 
					}

					if(!$AppDisplayName) { continue }

					$OutputObj = New-Object -TypeName PSobject 
					$OutputObj | Add-Member -MemberType NoteProperty -Name ComputerName -Value $ComputerName
					$OutputObj | Add-Member -MemberType NoteProperty -Name ComputerDomain -Value $domainName
					$OutputObj | Add-Member -MemberType NoteProperty -Name DisplayName -Value $AppDisplayName
					$OutputObj | Add-Member -MemberType NoteProperty -Name InstalledDate -Value $AppInstalledDate
					$OutputObj | Add-Member -MemberType NoteProperty -Name VersionMajor -Value $AppVersionMajor
					$OutputObj | Add-Member -MemberType NoteProperty -Name DisplayVersion -Value $AppVersion
					$OutputObj | Add-Member -MemberType NoteProperty -Name Publisher -Value $AppPublisher

					$results += $OutputObj						
				}
			} catch {
				LogText "Error processing user key $HKUser"
				Continue
			}
		}
	}

	if ($results) {
		$results | Export-Csv -Path $OutputFile1 -NoTypeInformation -Encoding UTF8
		LogProgress "Scan complete. $($results.Count) products found."
	}
	else {
		LogError "Unable to scan $ComputerName"
	}
}


function Get-SystemFile {

	## Array for storing csv file details
	$results = @()
	$flag = 0

	$OS = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"
	
	if(!(Test-Connection -ComputerName $ComputerName -Count 1 -ea 0)) {
		LogError "$ComputerName not reachable. Script Exiting"
		exit
	}
	
	try {
		LogProgress "Connecting to $ComputerName Remote Registry service ($OS)"

		$HKLM = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',$ComputerName)
		$OSRef = $HKLM.OpenSubKey($OS)
			
		$CurrentVersion  = $($OSRef.GetValue("CurrentVersion"))
		$ProductName  = $($OSRef.GetValue("ProductName"))
			
		$OutputObj = New-Object -TypeName PSobject 
			
		$OutputObj | Add-Member -MemberType NoteProperty -Name ComputerName -Value $ComputerName
		$OutputObj | Add-Member -MemberType NoteProperty -Name Name -Value $ComputerName
		$OutputObj | Add-Member -MemberType NoteProperty -Name Caption -Value $ProductName
		$OutputObj | Add-Member -MemberType NoteProperty -Name TypeDescription -Value ""
		$OutputObj | Add-Member -MemberType NoteProperty -Name BuildNumber -Value ""
		$OutputObj | Add-Member -MemberType NoteProperty -Name FullVersion -Value $CurrentVersion
		$OutputObj | Add-Member -MemberType NoteProperty -Name ServicePack -Value ""
		$OutputObj | Add-Member -MemberType NoteProperty -Name ComputerDomain -Value $env:USERDNSDOMAIN
		$OutputObj | Add-Member -MemberType NoteProperty -Name TotalPhysicalMemory -Value ""
		$OutputObj | Add-Member -MemberType NoteProperty -Name Model -Value ""
		$OutputObj | Add-Member -MemberType NoteProperty -Name Manufacturer -Value ""
		$OutputObj | Add-Member -MemberType NoteProperty -Name BiosManufacturer -Value ""
		$OutputObj | Add-Member -MemberType NoteProperty -Name ScriptName -Value "Get-InstalledSoftware.ps1"	
						
		} catch {
			LogText "Unable to open root key $OS"
			Continue
		}
	
	$results += $OutputObj
	
	if ($results) {
		$results | Export-Csv -Path $OutputFile2 -NoTypeInformation -Encoding UTF8
		LogProgress "System file generated."
	}
	else {
		LogError "Unable to scan $ComputerName"
	}
	
}

Get-InstalledSoftwareList
Get-SystemFile