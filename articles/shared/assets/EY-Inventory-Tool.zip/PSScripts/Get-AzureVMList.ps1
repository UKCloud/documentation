 #########################################################
 #                                                                     
 # Get-AzureVMList
 #
 #########################################################

 <#
.SYNOPSIS
Retrieves Azure installation data from a added Microsoft account

.DESCRIPTION
Retrieves installation information from resource manager (AzureRM) and the newer version of it (Az) Azure VM for multiple accounts and outputs this information to a csv file. 
This information includes SubscriptionId, SubscriptionName, Environment supported modes, DefaultAccount and more.
The User needs to pass the credentials to execute the script.

.PARAMETER      USERNAME
Enter only Organisational (work) or Student Azure Account Username

.PARAMETER       PASSWORD
Azure Account Password

.PARAMETER OUTPUTFILE1
Output CSV file to store the results

EXAMPLE DATA FOR RM VM

SubscriptionId = 3de1d721-xxxx-xxxx-xxxx-xxxxxxxxd3f6
SubscriptionName = Visual Studio Professional Subscription
Resource Group Name = [resource-group--name]
VM Name = [vm-name]
Guest Hostname = [guest-hostname (network name)]
OS = WindowsServer
Status = [Provisioning succeeded/VM running/etc.]
License Type = 
Location = northeurope
Availability Set = [set-name]
Instance Size = Standard_B1s
Admin Username = AdminName
VM Provisioning State = Succeeded
Creation Method = FromImage
Publisher = MicrosoftWindowsServer
VM Image Name = 2019-Datacenter
VM Image Version = latest
VM Private IP Address = xxx.xxx.xxx.xxx
VM Private IP Allocation Method = [Dynamic/Static]

#>

Param(
	$AzureUserName,
	$AzurePassword,
	[alias("o1")]
	$OutputFile1 = "_EY_AzureVMList.csv",
	[alias("log")]
	[string] $LogFile = "_EY_AzureQueryLog.txt",
	[switch]
	$Verbose
)

function InitialiseLogFile {
	if ($LogFile -and (Test-Path $LogFile)) {
		Remove-Item $LogFile
	}
}

function LogText {
	param(
		[Parameter(Position=0, ValueFromRemainingArguments=$true, ValueFromPipeline=$true)]
		[Object] $Object,
		[System.ConsoleColor]$color = [System.Console]::ForegroundColor,
		[switch]$noNewLine = $false 
	)

	# Display text on screen
	Write-Host -Object $Object -ForegroundColor $color -NoNewline:$noNewLine

	if ($LogFile) {
		$Object | Out-File $LogFile -Encoding utf8 -Append 
	}
}

function LogProgress([string]$Activity, [string]$Status, [Int32]$PercentComplete, [switch]$Completed ){
	
	Write-Progress -activity $Activity -Status $Status -percentComplete $PercentComplete -Completed:$Completed

	$output = Get-Date -Format HH:mm:ss.ff
	$output += " - "
	$output += $Status
	LogText $output -Color Green
}

function LogError([string[]]$errorDescription){
	if ($Verbose){
		LogText ""
	}

	$output = Get-Date -Format HH:mm:ss.ff
	$output += " - "
	$output += $errorDescription -join "`r`n              "
	LogText $output -Color Red
	Start-Sleep -s 3
}

function LogLastException() {
    $currentException = $Error[0].Exception;

    while ($currentException)
    {
        LogText -Color Red $currentException
        LogText -Color Red $currentException.Data
        LogText -Color Red $currentException.HelpLink
        LogText -Color Red $currentException.HResult
        LogText -Color Red $currentException.Message
        LogText -Color Red $currentException.Source
        LogText -Color Red $currentException.StackTrace
        LogText -Color Red $currentException.TargetSite

        $currentException = $currentException.InnerException
    }

	Start-Sleep -s 3
}

function QueryUser([string]$Message, [string]$Prompt, [switch]$AsSecureString = $false, [string]$DefaultValue){
	if ($Message) {
		LogText $Message -color Yellow
	}

	if ($DefaultValue) {
		$Prompt += " (Default [$DefaultValue])"
	}

	$Prompt += ": "
	LogText $Prompt -color Yellow -NoNewLine
	$strResult = Read-Host -AsSecureString:$AsSecureString

	if(!$strResult) {
		$strResult = $DefaultValue
	}

	return $strResult
}

                                                                          
function LogEnvironmentDetails {
	LogText -Color Gray " "
	LogText -Color Gray "  ###########################################################"
	LogText -Color Gray "  #       _______     __                                    #"
	LogText -Color Gray "  #      |  ___\ \   / /                                    #"
	LogText -Color Gray "  #      | |__  \ \_/ /                                     #"
	LogText -Color Gray "  #      |  __|  \   /                  Ernst & Young       #"
	LogText -Color Gray "  #      | |____  | |        Windows Inventory Script       #"
	LogText -Color Gray "  #      |______| |_|                                       #"
	LogText -Color Gray "  #                                                         #"
	LogText -Color Gray "  ###########################################################"
	LogText -Color Gray " "
	LogText -Color Gray " Get-AzureVMList.ps1"
	LogText -Color Gray " "

	$OSDetails = Get-WmiObject Win32_OperatingSystem
	LogText -Color Gray "Computer Name:        $($env:COMPUTERNAME)"
	LogText -Color Gray "User Name:            $($env:USERNAME)@$($env:USERDNSDOMAIN)"
	LogText -Color Gray "Windows Version:      $($OSDetails.Caption)($($OSDetails.Version))"
	LogText -Color Gray "PowerShell Host:      $($host.Version.Major)"
	LogText -Color Gray "PowerShell Version:   $($PSVersionTable.PSVersion)"
	LogText -Color Gray "PowerShell Word size: $($([IntPtr]::size) * 8) bit"
	LogText -Color Gray "CLR Version:          $($PSVersionTable.CLRVersion)"
	LogText -Color Gray "Current Date Time:    $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
	LogText -Color Gray "Username Parameter:   $AzureUserName"
	LogText -Color Gray "Username Parameter:   $InstallDependency"
	LogText -Color Gray "Output File 1:        $OutputFile1"
	LogText -Color Gray "Log File:             $LogFile"
	LogText -Color Gray ""
}

function SetupDateFormats {
    # Standardise date/time output to ISO 8601'ish format
    $bDateFormatConfigured = $false
    $currentThread = [System.Threading.Thread]::CurrentThread
    
    try {
        $CurrentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = 'yyyy-MM-dd'
        $CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern = 'yyyy-MM-dd HH:mm:ss'
        $bDateFormatConfigured = $true
    }
    catch {
    }

    if (!($bDateFormatConfigured)) {
        try {
            $cultureCopy = $CurrentThread.CurrentCulture.Clone()
            $cultureCopy.DateTimeFormat.ShortDatePattern = 'yyyy-MM-dd'
            $cultureCopy.DateTimeFormat.LongDatePattern = 'yyyy-MM-dd HH:mm:ss'
            $currentThread.CurrentCulture = $cultureCopy
        }
        catch {
        }
    }
}


function ConfigureAzureEnvironment() {
	
	LogProgress -Activity "Azure Data Export" -Status "Configuring Environment" -percentComplete 0

	# Option 1. Try loading Az modules if installed 
	if ((Get-Module -ListAvailable -Name 'Az.Accounts') -and 
		(Get-Module -ListAvailable -Name 'Az.Network') -and 
		(Get-Module -ListAvailable -Name 'Az.Compute')) {

		# load required modules 
		Import-Module Az.Accounts
		Import-Module Az.Network
		Import-Module Az.Compute
		LogProgress -Activity "Azure Data Export" -Status "Az Modules Loaded" -percentComplete 25

		return 'Az'
	}

	# OPtioin 2. Try loading AzureRM modules if installed 
	if ((Get-Module -ListAvailable -Name 'AzureRM.Profile') -and 
		(Get-Module -ListAvailable -Name 'AzureRM.Network') -and 
		(Get-Module -ListAvailable -Name 'AzureRM.Compute')) {
			
		# load required modules 
		Import-Module AzureRM.Profile
		Import-Module AzureRM.Network
		Import-Module AzureRM.Compute
		LogProgress -Activity "Azure Data Export" -Status "AzureRm Module Loaded" -percentComplete 25

		return 'AzureRm'
	}

	# Option 3. Required component(s) not installed. Ask if user wants to install this manually or try auto-install of required Az modules.
	if (-Not $InstallComponentsIfRequired) {
		LogText 'The required PowerShell Azure components are not installed on this device.'
		LogText 'Either of these PowerShell Modules is required:'
		LogText ' 1) Az (preferable option)'
		LogText ' 2) AzureRm (replaced by Az, but still supported by Microsoft)'
		LogText ''
		LogText 'If you want to install any of them manually please choose ''N'' option below. In this case please follow the guidance from here:'
		LogText ' 1) Az https://docs.microsoft.com/en-us/powershell/azure/install-az-ps?view=azps-6.1.0'
		LogText ' 1) AzureRM https://www.powershellgallery.com/packages/AzureRM/6.13.1'
		LogText ''
		$response = QueryUser -Prompt "Download and install required components (Y/N)"

		if (!($response -eq 'y' -or $response -eq 'Y')) {
			# User has chosen not to install required component(s)
			LogError 'Required component(s) missing. Script exiting.'
			return 'Error'
		}
	}

	if (Get-Module -ListAvailable -Name 'PowerShellGet')
	{		
		Install-Module Az.Accounts
		Install-Module Az.Network
		Install-Module Az.Compute
		# check if installation succeeded
		if (-Not(	(Get-Module -ListAvailable -Name 'Az.Accounts') -and 
					(Get-Module -ListAvailable -Name 'Az.Network') -and 
					(Get-Module -ListAvailable -Name 'Az.Compute')
				)) {
			LogError  	"Microsoft Az PowerShell Modules can not be installed. Please check if you have admin rights and try again." + [Environment]::NewLine +
			  		  	"Alternatively, you can install Microsoft Az PowerShell Modules manually. https://docs.microsoft.com/en-us/powershell/azure/install-az-ps?view=azps-6.1.0"
			return 'Error'
		}
	}			
	else {
		
		LogError  	"Microsoft Az PowerShell Module could not be installed. Install-Module command is not available. Please try one of the following options:" + [Environment]::NewLine +
					"1) Add 'Install-Module' command manually and run the script again. You can do this by installing PowerShellGet module: https://docs.microsoft.com/en-us/powershell/scripting/gallery/installing-psget" + [Environment]::NewLine +
					"2) Upgrade PowerShell version to 5.1 or higher: https://docs.microsoft.com/en-us/powershell/scripting/install/installing-powershell-core-on-windows?view=powershell-7.1" + [Environment]::NewLine +
					"3) Install Microsoft Az PowerShell Module manually. https://docs.microsoft.com/en-us/powershell/azure/install-az-ps?view=azps-6.1.0" + [Environment]::NewLine
		return 'Error'
	}
                                              
	LogProgress -Activity "Azure Data Export" -Status "Loading Modules" -percentComplete 20
	if (-Not 	(	(Get-Module -ListAvailable -Name 'Az.Accounts') -and 
					(Get-Module -ListAvailable -Name 'Az.Network') -and 
					(Get-Module -ListAvailable -Name 'Az.Compute')
				)) {
		LogError "An error occured while installing a required component - Az Module. Script exiting."
		return 'Error'
	}

	Import-Module Az.Accounts
	Import-Module Az.Network
	Import-Module Az.Compute
	LogProgress -Activity "Azure Data Export" -Status "Az Modules Loaded" -percentComplete 25

	return 'Az'
}

function Get-AzureVMListRM {

	##
    ## Get AzureRM(ARM) VM details
    ##
	try {
		$percent = 50
		Disconnect-AzureRmAccount

		## Process the user credentials passed through terminal
		if ($AzureUserName -and $AzurePassword) {
			$securePassword = ConvertTo-SecureString $AzurePassword -AsPlainText -Force

			## Convert to Azure account aceptable		
			$cred = New-Object -TypeName System.Management.Automation.PSCredential ($AzureUserName, $securePassword)
				
            $percent = $percent + 2
			LogProgress -activity "Azure Data Export" -Status "Logging in with command line credentials" -percentComplete $percent
			
            ## Login the account user has entered
			$AzureAccount = Add-AzureRmAccount -Credential $cred -ErrorAction SilentlyContinue -ErrorVariable errAddAccount
            if ($errAddAccount.count -ne 0) {
                LogError -errorDescription "An error occured while trying to login into the account. Please check your credentials or try again later."
                return
            }
		}
		else {
            $percent = $percent + 2
			LogProgress -activity "Azure Data Export" -Status "Azure Credentials Required" -percentComplete $percent
			$AzureAccount = Add-AzureRmAccount -ErrorAction SilentlyContinue -ErrorVariable errAddAccount
            
            if ($errAddAccount.count -ne 0) {
                LogError -errorDescription "An error occured while trying to login into the Azure account. Please check your credentials or try again later."
				return
            }
		}

		## Get the Subscription List
        $percent = $percent + 2
		LogProgress -activity "Azure Data Export" -Status "Credentials accepted, Get Azure Subscription Details" -percentComplete $percent
		$subscriptions = Get-AzureRmSubscription -ErrorVariable AzSubscriptionError -ErrorAction Stop

		$subscriptionCount = $subscriptions.count
		$tempValue = [int](40 / [math]::max( $subscriptionCount , 1 ))
		$subInterval = [int]($tempValue / 3)

		if ($Verbose) {
            LogText "$subscriptionCount subscription(s) found"
            LogText ($subscriptions | Format-Table -property SubscriptionName, SubscriptionID -autosize | Out-String)
        }
		
        $percent = $percent + 1
		
        ## Array for storing csv file details
        $results = @()

        ## Loop through each subscription
        foreach ($subscription in $subscriptions) {
	        $percent += $subInterval

	        ## Get Subscription basic details
	        $SubscriptionId = $subscription.Id
	        $SubscriptionName = $subscription.Name

		    ## Check if user has access to the subscription
            try {
	            ## Set Default Subscription to get all its details
	            $selectedSub = Select-AzureRmSubscription -SubscriptionId $SubscriptionId
            }
            catch {
		        LogError -errorDescription "The current user does not has access to Azure subscription - $SubscriptionName ($SubscriptionId)." -color Red
		        Continue
            }

	        ## Check if the session is expired
	        ## Throws an exception if session is expired
	        try {
				$percent += $subInterval
				LogProgress -activity "Azure Data Export" -Status "Querying subscription - $SubscriptionName ($SubscriptionId)" -percentComplete $percent

		        $vmList = Get-AzureRmVM -EV vmListError -EA SilentlyContinue
                if ($null -eq $vmList) {
                    Continue
                }

		        $vmListtype = $vmList.GetType()
	        }			
	        catch {
		        ## Remove the saved user account credentials, if session has expired
		        LogError -errorDescription "An error occurred querying VMs for subscription - $SubscriptionName ($SubscriptionId). Credentials may have expired." -color Red
		        Continue
	        }

	        ## Interval decided upon previous completion divided by Number of VM's and
	        ## further divided by 5 main process
	        $vmCount = $vmList.count
	        $vmPercentInterval = [int]($subInterval / $vmCount)

	        foreach ($vm in $vmList) { 
	            $percent += $vmPercentInterval
	            
				if ($Verbose) {
                    LogText "Querying VM $($vm.Name)"
                }

                $rgn = $vm.ResourceGroupName

                $vmDetails = $subscription | Select-Object -Property @{N='SubscriptionId';E={$_.Id}}, @{N='SubscriptionName';E={$_.Name}}

                ## Parse VM OS Profile
                $ospt = $vm.OSProfile
				
                ## Parse VM OS Details
                $spt = $vm.StorageProfile
        
                ## Parse VM Hardware Details
                $hpt = $vm.HardwareProfile
              
                ## Parse VM Network Details
                $vmNIId = ($vm.NetworkProfile.NetworkInterfaces.ID -split "/")[-1]
                $vmNI = Get-AzureRmNetworkInterface -Name $vmNIId -ResourceGroupName $rgn

				## Get VM Status
				$vms = Get-AzureRmVM -Name $vm.Name -ResourceGroupName $rgn -EA SilentlyContinue -Status

				## Read all statuses of the VM
				$VMStatusDetail = ""
				foreach ($VMStatus in $vms.Statuses)
				{ 
					$VMStatusDetail += "$($VMStatus.DisplayStatus);"
				}
				
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Resource Group Name" -Value $rgn
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "VM Name" -Value $vm.Name
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Guest Hostname" -Value "" # not available in AzureRM
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "OS" -Value $spt.imageReference.offer
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Status" -Value $VMStatusDetail
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "License Type" -Value $vm.LicenseType
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Location" -Value $vm.Location
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Availability Set" -Value $vm.AvailabilitySetReference
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Instance Size" -Value $hpt.vmSize
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Admin Username" -Value $ospt.adminUsername
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "VM Provisioning State" -Value $vm.ProvisioningState
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Creation Method" -Value $spt.osDisk.createOption
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Publisher" -Value $spt.imageReference.publisher
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "VM Image Name" -Value $spt.imageReference.sku
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "VM Image Version" -Value $spt.imageReference.version
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "VM Private IP Address" -Value $vmNI.IpConfigurations.PrivateIpAddress
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "VM Private IP Allocation Method" -Value $vmNI.IpConfigurations.PrivateIpAllocationMethod

		        $results += $vmDetails
	        }
            			
        }       
        
	    $percent += 2
	                    
		$results | Export-Csv -Path $OutputFile1 -NoTypeInformation -Encoding UTF8
        
		# Clear the logged in user session.
		Disconnect-AzureRmAccount
         
	    $percent = 100
		LogProgress -activity "Azure Data Export" -Status "Azure VM List Export Completed" -percentComplete $percent             
		                
	} 
    catch {
		LogLastException

        ## An error occured. Clear the logged in user session.
        Disconnect-AzureRmAccount
	}
}

function Get-AzVMList {

	##
    ## Get Az module VM details (successor of AzureRM(ARM))
    ##
	try {
		$percent = 50
		Disconnect-AzAccount

		## Process the user credentials passed through terminal
		if ($AzureUserName -and $AzurePassword) {
			$securePassword = ConvertTo-SecureString $AzurePassword -AsPlainText -Force

			## Convert to Azure account aceptable		
			$cred = New-Object -TypeName System.Management.Automation.PSCredential ($AzureUserName, $securePassword)
				
            $percent = $percent + 2
			LogProgress -activity "Azure Data Export" -Status "Logging in with command line credentials" -percentComplete $percent
			
            ## Login the account user has entered
			$AzureAccount = Connect-AzAccount -Credential $cred -ErrorAction SilentlyContinue -ErrorVariable errAddAccount
            if ($errAddAccount.count -ne 0) {
                LogError -errorDescription "An error occured while trying to login into the Azure account. Please check your credentials or try again later."
                return
            }
		}
		else {
            $percent = $percent + 2
			LogProgress -activity "Azure Data Export" -Status "Azure Credentials Required" -percentComplete $percent
			$AzureAccount = Connect-AzAccount -ErrorAction SilentlyContinue -ErrorVariable errAddAccount
            
            if ($errAddAccount.count -ne 0) {
                LogError -errorDescription "An error occured while trying to login into the Azure account. Please check your credentials or try again later."
				return
            }
		}

		## Get the Subscription List
        $percent = $percent + 2
		LogProgress -activity "Azure Data Export" -Status "Credentials accepted, Get Azure Subscription Details" -percentComplete $percent
		$subscriptions = Get-AzSubscription -ErrorVariable AzSubscriptionError -ErrorAction Stop

		$subscriptionCount = $subscriptions.count
		$tempValue = [int](40 / [math]::max( $subscriptionCount , 1 ))
		$subInterval = [int]($tempValue / 3)

		if ($Verbose) {
            LogText "$subscriptionCount subscription(s) found"
            LogText ($subscriptions | Format-Table -property Name, ID -autosize | Out-String)
        }
		
        $percent = $percent + 1
		
        ## Array for storing csv file details
        $results = @()

        ## Loop through each subscription
        foreach ($subscription in $subscriptions) {
	        $percent += $subInterval

	        ## Get Subscription basic details
	        $SubscriptionId = $subscription.Id
	        $SubscriptionName = $subscription.Name

		    ## Check if user has access to the subscription
            try {
	            ## Set Default Subscription to get all its details
	            $selectedSub = Set-AzContext -SubscriptionId $SubscriptionId
            }
            catch {
		        LogError -errorDescription "The current user does not has access to Azure subscription - $SubscriptionName ($SubscriptionId)." -color Red
		        Continue
            }

	        ## Check if the session is expired
	        ## Throws an exception if session is expired
	        try {
				$percent += $subInterval
				LogProgress -activity "Azure Data Export" -Status "Querying subscription - $SubscriptionName ($SubscriptionId)" -percentComplete $percent

		        $vmList = Get-AzVM -EV vmListError -EA SilentlyContinue
                if ($null -eq $vmList) {
                    Continue
                }

		        $vmListtype = $vmList.GetType()
	        }			
	        catch {
		        ## Remove the saved user account credentials, if session has expired
		        LogError -errorDescription "An error occurred querying VMs for subscription - $SubscriptionName ($SubscriptionId). Credentials may have expired." -color Red
		        Continue
	        }

	        ## Interval decided upon previous completion divided by Number of VM's and
	        ## further divided by 5 main process
	        $vmCount = $vmList.count
	        $vmPercentInterval = [int]($subInterval / $vmCount)

	        foreach ($vm in $vmList) { 
	            $percent += $vmPercentInterval
	            
				if ($Verbose) {
                    LogText "Querying VM $($vm.Name)"
                }

                $rgn = $vm.ResourceGroupName

                $vmDetails = $subscription | Select-Object -Property @{N='SubscriptionId';E={$_.Id}}, @{N='SubscriptionName';E={$_.Name}}

                ## Parse VM OS Profile
                $ospt = $vm.OSProfile
				
                ## Parse VM OS Details
                $spt = $vm.StorageProfile
        
                ## Parse VM Hardware Details
                $hpt = $vm.HardwareProfile
              
                ## Parse VM Network Details
                $vmNIId = ($vm.NetworkProfile.NetworkInterfaces.ID -split "/")[-1]
                $vmNI = Get-AzNetworkInterface -Name $vmNIId -ResourceGroupName $rgn

				## Get Guest Host Name of the VM (note $vm.OSProfile.ComputerName is similar to VM name)
				$vms = Get-AzVM -Name $vm.Name -ResourceGroupName $rgn -EA SilentlyContinue -Status

				## Read all statuses of the VM
				$VMStatusDetail = ""
				foreach ($VMStatus in $vms.Statuses)
				{ 
					$VMStatusDetail += "$($VMStatus.DisplayStatus);"
				}

		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Resource Group Name" -Value $rgn
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "VM Name" -Value $vm.Name
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Guest Hostname" -Value $vms.ComputerName
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "OS" -Value $spt.imageReference.offer
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Status" -Value $VMStatusDetail
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "License Type" -Value $vm.LicenseType
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Location" -Value $vm.Location
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Availability Set" -Value $vm.AvailabilitySetReference
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Instance Size" -Value $hpt.vmSize
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Admin Username" -Value $ospt.adminUsername
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "VM Provisioning State" -Value $vm.ProvisioningState
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Creation Method" -Value $spt.osDisk.createOption
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "Publisher" -Value $spt.imageReference.publisher
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "VM Image Name" -Value $spt.imageReference.sku
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "VM Image Version" -Value $spt.imageReference.version
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "VM Private IP Address" -Value $vmNI.IpConfigurations.PrivateIpAddress
		        $vmDetails | Add-Member -MemberType NoteProperty -Name "VM Private IP Allocation Method" -Value $vmNI.IpConfigurations.PrivateIpAllocationMethod

		        $results += $vmDetails
	        }
            			
        }       
        
	    $percent += 2
	                    
		$results | Export-Csv -Path $OutputFile1 -NoTypeInformation -Encoding UTF8
        
		# Clear the logged in user session.
		Disconnect-AzAccount
         
	    $percent = 100
		LogProgress -activity "Azure Data Export" -Status "Azure VM List Export Completed" -percentComplete $percent             
		                
	} 
    catch {
		LogLastException

        ## An error occured. Clear the logged in user session.
        Disconnect-AzAccount
	}
}


function Get-AzureVMList {	
	SetupDateFormats
    InitialiseLogFile
	LogEnvironmentDetails

	switch -Exact (ConfigureAzureEnvironment)
	{
		'Az' {Get-AzVMList}
		'AzureRM' {Get-AzureVMListRM}
		Default {
			return
		}
	}

}

Get-AzureVMList